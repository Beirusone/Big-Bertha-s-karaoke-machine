package com.example

import android.Manifest
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.media.AudioDeviceInfo
import android.media.AudioManager
import android.os.Build
import android.os.Bundle
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.*
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.content.ContextCompat
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.services.KaraokeService
import com.example.ui.theme.MyApplicationTheme
import kotlin.math.roundToInt

class MainActivity : ComponentActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            MyApplicationTheme {
                MainScreen()
            }
        }
    }
}

@Composable
fun MainScreen() {
    val context = LocalContext.current

    // State flows from the Foreground Service
    val isMicActive by KaraokeService.isMicActive.collectAsStateWithLifecycle()
    val micVolume by KaraokeService.micVolume.collectAsStateWithLifecycle()
    val amplitude by KaraokeService.amplitude.collectAsStateWithLifecycle()
    val isAecEnabled by KaraokeService.isAecEnabled.collectAsStateWithLifecycle()

    // Permissions State
    var hasAudioPermission by remember {
        mutableStateOf(
            ContextCompat.checkSelfPermission(context, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED
        )
    }
    var hasNotificationPermission by remember {
        mutableStateOf(
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                ContextCompat.checkSelfPermission(context, Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED
            } else {
                true
            }
        )
    }

    val requestPermissionsLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestMultiplePermissions()
    ) { results ->
        hasAudioPermission = results[Manifest.permission.RECORD_AUDIO] ?: false
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            hasNotificationPermission = results[Manifest.permission.POST_NOTIFICATIONS] ?: false
        }
    }

    // Automatically request permissions on launch if missing
    LaunchedEffect(Unit) {
        val permissionsToRequest = mutableListOf<String>()
        if (!hasAudioPermission) permissionsToRequest.add(Manifest.permission.RECORD_AUDIO)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU && !hasNotificationPermission) {
            permissionsToRequest.add(Manifest.permission.POST_NOTIFICATIONS)
        }
        if (permissionsToRequest.isNotEmpty()) {
            requestPermissionsLauncher.launch(permissionsToRequest.toTypedArray())
        }
    }

    // Headphone connectivity state
    var isHeadphonesConnected by remember { mutableStateOf(checkHeadphones(context)) }

    DisposableEffect(context) {
        val receiver = object : BroadcastReceiver() {
            override fun onReceive(context: Context, intent: Intent) {
                if (intent.action == Intent.ACTION_HEADSET_PLUG) {
                    val state = intent.getIntExtra("state", 0)
                    isHeadphonesConnected = (state > 0)
                }
            }
        }
        val filter = IntentFilter(Intent.ACTION_HEADSET_PLUG)
        context.registerReceiver(receiver, filter)
        onDispose {
            context.unregisterReceiver(receiver)
        }
    }

    // Floating WebView states
    var isWebViewVisible by remember { mutableStateOf(false) }
    var webViewUrl by remember { mutableStateOf("https://m.youtube.com") }
    var webViewInstance by remember { mutableStateOf<WebView?>(null) }
    var isWebViewMinimized by remember { mutableStateOf(false) }

    // Coordinates for floating card dragging
    var webViewOffsetX by remember { mutableStateOf(20f) }
    var webViewOffsetY by remember { mutableStateOf(300f) }

    // Layout
    Scaffold(
        modifier = Modifier.fillMaxSize(),
        contentWindowInsets = WindowInsets.safeDrawing
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(Color(0xFF0B0014)) // Deep cyber void background
                .padding(innerPadding)
        ) {
            // Main content column
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(horizontal = 20.dp)
            ) {
                // Header Banner
                HeaderSection()

                Spacer(modifier = Modifier.height(16.dp))

                // Alert Banner about headphones (Critical UX)
                HeadphoneAlertBanner(isHeadphonesConnected)

                Spacer(modifier = Modifier.height(16.dp))

                // Microphone Controller Card
                MicrophoneControllerCard(
                    hasAudioPermission = hasAudioPermission,
                    isMicActive = isMicActive,
                    micVolume = micVolume,
                    amplitude = amplitude,
                    isAecEnabled = isAecEnabled,
                    onRequestPermission = {
                        requestPermissionsLauncher.launch(
                            arrayOf(Manifest.permission.RECORD_AUDIO)
                        )
                    },
                    onToggleMic = {
                        if (isMicActive) {
                            KaraokeService.stopService(context)
                        } else {
                            if (hasAudioPermission) {
                                KaraokeService.startService(context)
                            }
                        }
                    },
                    onVolumeChange = { KaraokeService.setMicVolume(it) }
                )

                Spacer(modifier = Modifier.height(16.dp))

                // YouTube Backing Track search helper
                YouTubeHelperCard(
                    onSearchQuery = { query ->
                        val formatted = query.replace(" ", "+")
                        webViewUrl = "https://m.youtube.com/results?search_query=$formatted+karaoke"
                        webViewInstance?.loadUrl(webViewUrl)
                        isWebViewVisible = true
                        isWebViewMinimized = false
                    },
                    onToggleWebView = {
                        isWebViewVisible = !isWebViewVisible
                        if (isWebViewVisible) isWebViewMinimized = false
                    },
                    isWebViewVisible = isWebViewVisible
                )

                Spacer(modifier = Modifier.height(24.dp))
            }

            // Draggable Floating YouTube WebView overlay
            AnimatedVisibility(
                visible = isWebViewVisible,
                enter = fadeIn(animationSpec = spring()),
                exit = fadeOut(animationSpec = spring())
            ) {
                if (isWebViewMinimized) {
                    // Small floating orb/bubble when minimized
                    Box(
                        modifier = Modifier
                            .offset { IntOffset(webViewOffsetX.roundToInt(), webViewOffsetY.roundToInt()) }
                            .size(64.dp)
                            .background(
                                Brush.linearGradient(listOf(Color(0xFF00E5FF), Color(0xFFBC00DD))),
                                CircleShape
                            )
                            .border(2.dp, Color.White, CircleShape)
                            .clickable { isWebViewMinimized = false }
                            .pointerInput(Unit) {
                                detectDragGestures { change, dragAmount ->
                                    change.consume()
                                    webViewOffsetX += dragAmount.x
                                    webViewOffsetY += dragAmount.y
                                }
                            },
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Rounded.PlayArrow,
                            contentDescription = "Expand YouTube backing player",
                            tint = Color.White,
                            modifier = Modifier.size(32.dp)
                        )
                    }
                } else {
                    // Rich, full-featured floating resizable card
                    Card(
                        modifier = Modifier
                            .offset { IntOffset(webViewOffsetX.roundToInt(), webViewOffsetY.roundToInt()) }
                            .width(320.dp)
                            .height(420.dp)
                            .border(
                                1.5.dp,
                                Brush.linearGradient(listOf(Color(0xFFBC00DD), Color(0xFF00E5FF))),
                                RoundedCornerShape(16.dp)
                            )
                            .pointerInput(Unit) {
                                detectDragGestures { change, dragAmount ->
                                    change.consume()
                                    webViewOffsetX += dragAmount.x
                                    webViewOffsetY += dragAmount.y
                                }
                            }
                            .testTag("youtube_floating_card"),
                        shape = RoundedCornerShape(16.dp),
                        colors = CardDefaults.cardColors(containerColor = Color(0xFF130624)),
                        elevation = CardDefaults.cardElevation(defaultElevation = 12.dp)
                    ) {
                        Column(modifier = Modifier.fillMaxSize()) {
                            // Header Toolbar (Drag Handle)
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .background(Color(0xFF220E3D))
                                    .padding(horizontal = 12.dp, vertical = 6.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(
                                        imageVector = Icons.Rounded.MusicNote,
                                        contentDescription = "Music icon",
                                        tint = Color(0xFF00E5FF),
                                        modifier = Modifier.size(16.dp)
                                    )
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text(
                                        text = "YouTube Player",
                                        color = Color.White,
                                        fontSize = 13.sp,
                                        fontWeight = FontWeight.Bold
                                    )
                                }

                                Row {
                                    IconButton(
                                        onClick = { isWebViewMinimized = true },
                                        modifier = Modifier.size(24.dp)
                                    ) {
                                        Icon(
                                            imageVector = Icons.Rounded.Remove,
                                            contentDescription = "Minimize WebView",
                                            tint = Color.White,
                                            modifier = Modifier.size(16.dp)
                                        )
                                    }
                                    Spacer(modifier = Modifier.width(4.dp))
                                    IconButton(
                                        onClick = { isWebViewVisible = false },
                                        modifier = Modifier.size(24.dp)
                                    ) {
                                        Icon(
                                            imageVector = Icons.Rounded.Close,
                                            contentDescription = "Close WebView",
                                            tint = Color.White,
                                            modifier = Modifier.size(16.dp)
                                        )
                                    }
                                }
                            }

                            // WebView Navigation toolbar
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .background(Color(0xFF1B0B30))
                                    .padding(horizontal = 8.dp, vertical = 4.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Row {
                                    IconButton(
                                        onClick = { webViewInstance?.goBack() },
                                        enabled = webViewInstance?.canGoBack() == true,
                                        modifier = Modifier.size(32.dp)
                                    ) {
                                        Icon(
                                            imageVector = Icons.Filled.ArrowBack,
                                            contentDescription = "Back",
                                            tint = if (webViewInstance?.canGoBack() == true) Color(0xFF00E5FF) else Color.Gray,
                                            modifier = Modifier.size(20.dp)
                                        )
                                    }
                                    IconButton(
                                        onClick = { webViewInstance?.goForward() },
                                        enabled = webViewInstance?.canGoForward() == true,
                                        modifier = Modifier.size(32.dp)
                                    ) {
                                        Icon(
                                            imageVector = Icons.Filled.ArrowForward,
                                            contentDescription = "Forward",
                                            tint = if (webViewInstance?.canGoForward() == true) Color(0xFF00E5FF) else Color.Gray,
                                            modifier = Modifier.size(20.dp)
                                        )
                                    }
                                }

                                Row {
                                    IconButton(
                                        onClick = { webViewInstance?.reload() },
                                        modifier = Modifier.size(32.dp)
                                    ) {
                                        Icon(
                                            imageVector = Icons.Rounded.Refresh,
                                            contentDescription = "Reload",
                                            tint = Color(0xFFBC00DD),
                                            modifier = Modifier.size(18.dp)
                                        )
                                    }
                                    IconButton(
                                        onClick = {
                                            webViewUrl = "https://m.youtube.com"
                                            webViewInstance?.loadUrl(webViewUrl)
                                        },
                                        modifier = Modifier.size(32.dp)
                                    ) {
                                        Icon(
                                            imageVector = Icons.Rounded.Home,
                                            contentDescription = "Home",
                                            tint = Color(0xFF00E5FF),
                                            modifier = Modifier.size(18.dp)
                                        )
                                    }
                                }
                            }

                            // Embed actual Android WebView
                            AndroidView(
                                factory = { webViewContext ->
                                    WebView(webViewContext).apply {
                                        webViewClient = object : WebViewClient() {
                                            override fun onPageFinished(view: WebView?, url: String?) {
                                                super.onPageFinished(view, url)
                                                // Trigger simple refresh to enable state checks
                                                webViewUrl = url ?: ""
                                            }
                                        }
                                        settings.apply {
                                            javaScriptEnabled = true
                                            domStorageEnabled = true
                                            mediaPlaybackRequiresUserGesture = false
                                            useWideViewPort = true
                                            loadWithOverviewMode = true
                                            cacheMode = WebSettings.LOAD_DEFAULT
                                        }
                                        loadUrl(webViewUrl)
                                        webViewInstance = this
                                    }
                                },
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .weight(1f)
                                    .clip(RoundedCornerShape(bottomStart = 16.dp, bottomEnd = 16.dp))
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun HeaderSection() {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .height(130.dp)
            .clip(RoundedCornerShape(bottomStart = 24.dp, bottomEnd = 24.dp))
    ) {
        // High fidelity hero background banner generated via AI Studio tools
        Image(
            painter = painterResource(id = R.drawable.img_karaoke_hero),
            contentDescription = "Cyber Stage Banner",
            modifier = Modifier.fillMaxSize(),
            contentScale = ContentScale.Crop
        )

        // Dark gradient overlay for typography readability
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(
                    Brush.verticalGradient(
                        colors = listOf(Color.Transparent, Color(0xCC0B0014), Color(0xFF0B0014))
                    )
                )
        )

        // Title text
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(bottom = 12.dp, start = 16.dp, end = 16.dp),
            verticalArrangement = Arrangement.Bottom,
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(
                text = "BIG BERTHA'S KARAOKE",
                color = Color.White,
                fontSize = 24.sp,
                fontWeight = FontWeight.ExtraBold,
                textAlign = TextAlign.Center,
                letterSpacing = 2.sp
            )
            Text(
                text = "STAGE AUDIO PROCESSOR",
                color = Color(0xFF00E5FF),
                fontSize = 11.sp,
                fontWeight = FontWeight.Medium,
                letterSpacing = 4.sp
            )
        }
    }
}

@Composable
fun HeadphoneAlertBanner(isConnected: Boolean) {
    val infiniteTransition = rememberInfiniteTransition(label = "WarningGlow")
    val borderAlpha by infiniteTransition.animateFloat(
        initialValue = 0.3f,
        targetValue = 0.9f,
        animationSpec = infiniteRepeatable(
            animation = tween(1200, easing = LinearEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "Alpha"
    )

    if (!isConnected) {
        Surface(
            modifier = Modifier
                .fillMaxWidth()
                .border(
                    width = 1.5.dp,
                    color = Color(0xFFFFA726).copy(alpha = borderAlpha),
                    shape = RoundedCornerShape(12.dp)
                ),
            color = Color(0x1AFFA726),
            shape = RoundedCornerShape(12.dp)
        ) {
            Row(
                modifier = Modifier.padding(14.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(
                    imageVector = Icons.Rounded.Headphones,
                    contentDescription = "Warning Headphones Unplugged",
                    tint = Color(0xFFFFA726),
                    modifier = Modifier.size(24.dp)
                )
                Spacer(modifier = Modifier.width(12.dp))
                Column {
                    Text(
                        text = "Headphones Recommended",
                        color = Color.White,
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = "Using open speakers can cause screeching loop feedback. Plugin earphones for crystal clear monitoring.",
                        color = Color(0xFFE0E0E0),
                        fontSize = 11.sp,
                        lineHeight = 15.sp
                    )
                }
            }
        }
    } else {
        Surface(
            modifier = Modifier.fillMaxWidth(),
            color = Color(0x1A00E5FF),
            shape = RoundedCornerShape(12.dp),
            border = BorderStroke(1.dp, Color(0xFF00E5FF).copy(alpha = 0.4f))
        ) {
            Row(
                modifier = Modifier.padding(14.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(
                    imageVector = Icons.Rounded.Headphones,
                    contentDescription = "Headphones Connected Indicator",
                    tint = Color(0xFF00E5FF),
                    modifier = Modifier.size(24.dp)
                )
                Spacer(modifier = Modifier.width(12.dp))
                Column {
                    Text(
                        text = "Earphone Monitor Active",
                        color = Color.White,
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = "Enjoy low-latency vocals blended directly with your backing tracks.",
                        color = Color(0xFFE0E0E0),
                        fontSize = 11.sp,
                        lineHeight = 15.sp
                    )
                }
            }
        }
    }
}

@Composable
fun MicrophoneControllerCard(
    hasAudioPermission: Boolean,
    isMicActive: Boolean,
    micVolume: Float,
    amplitude: Float,
    isAecEnabled: Boolean,
    onRequestPermission: () -> Unit,
    onToggleMic: () -> Unit,
    onVolumeChange: (Float) -> Unit
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = Color(0xFF160A24)),
        border = BorderStroke(1.dp, Color(0xFFBC00DD).copy(alpha = 0.3f))
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(20.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(
                text = "MIC MONITOR CONTROL",
                color = Color.White,
                fontSize = 14.sp,
                fontWeight = FontWeight.Bold,
                letterSpacing = 2.sp,
                modifier = Modifier.align(Alignment.Start)
            )

            Spacer(modifier = Modifier.height(20.dp))

            if (!hasAudioPermission) {
                Column(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Icon(
                        imageVector = Icons.Rounded.MicOff,
                        contentDescription = "Permission Needed",
                        tint = Color(0xFFBC00DD),
                        modifier = Modifier.size(56.dp)
                    )
                    Spacer(modifier = Modifier.height(10.dp))
                    Text(
                        text = "Audio Permission Required",
                        color = Color.White,
                        fontSize = 15.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = "Please enable recording access so the app can output your voice to the monitor.",
                        color = Color.Gray,
                        fontSize = 12.sp,
                        textAlign = TextAlign.Center,
                        modifier = Modifier.padding(horizontal = 20.dp, vertical = 6.dp)
                    )
                    Spacer(modifier = Modifier.height(12.dp))
                    Button(
                        onClick = onRequestPermission,
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFBC00DD)),
                        modifier = Modifier.testTag("request_permission_button")
                    ) {
                        Text("Grant Permission", color = Color.White)
                    }
                }
            } else {
                // Interactive Mic Toggle Area
                Box(
                    contentAlignment = Alignment.Center,
                    modifier = Modifier.size(140.dp)
                ) {
                    // Pulsing Outer Rings (visualizer feedback)
                    val pulseScale by animateFloatAsState(
                        targetValue = if (isMicActive) 1f + (amplitude * 0.8f) else 1f,
                        animationSpec = spring(dampingRatio = Spring.DampingRatioMediumBouncy, stiffness = Spring.StiffnessLow),
                        label = "PulsingScale"
                    )

                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .scale(pulseScale)
                            .background(
                                brush = Brush.radialGradient(
                                    colors = if (isMicActive) {
                                        listOf(Color(0xFFBC00DD).copy(alpha = 0.4f), Color.Transparent)
                                    } else {
                                        listOf(Color(0xFF2E1A47).copy(alpha = 0.4f), Color.Transparent)
                                    }
                                ),
                                shape = CircleShape
                            )
                    )

                    // Glow button border
                    Box(
                        modifier = Modifier
                            .size(100.dp)
                            .border(
                                width = 3.dp,
                                brush = Brush.linearGradient(
                                    colors = if (isMicActive) {
                                        listOf(Color(0xFF00E5FF), Color(0xFFBC00DD))
                                    } else {
                                        listOf(Color(0xFF5A4475), Color(0xFF2E1A47))
                                    }
                                ),
                                shape = CircleShape
                            )
                            .clip(CircleShape)
                            .background(if (isMicActive) Color(0xFF2B004F) else Color(0xFF211530))
                            .clickable { onToggleMic() }
                            .testTag("mic_toggle_button"),
                        contentAlignment = Alignment.Center
                    ) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Icon(
                                imageVector = if (isMicActive) Icons.Rounded.Mic else Icons.Rounded.MicOff,
                                contentDescription = "Mic Toggle Button",
                                tint = if (isMicActive) Color(0xFF00E5FF) else Color(0xFF8B77A5),
                                modifier = Modifier.size(36.dp)
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = if (isMicActive) "ACTIVE" else "START MIC",
                                color = if (isMicActive) Color.White else Color(0xFF8B77A5),
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                // Realtime Amplitude Wave Visualizer
                AudioVisualizer(
                    amplitude = if (isMicActive) amplitude else 0.02f,
                    modifier = Modifier
                        .fillMaxWidth(0.9f)
                        .height(36.dp)
                )

                Spacer(modifier = Modifier.height(18.dp))

                // Volume slider
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        imageVector = Icons.Rounded.VolumeDown,
                        contentDescription = "Volume icon",
                        tint = Color.Gray,
                        modifier = Modifier.size(20.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Column(modifier = Modifier.weight(1f)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(
                                text = "Vocal Gain Booster",
                                color = Color.LightGray,
                                fontSize = 12.sp
                            )
                            Text(
                                text = "${(micVolume * 100).roundToInt()}%",
                                color = Color(0xFF00E5FF),
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                        Slider(
                            value = micVolume,
                            onValueChange = onVolumeChange,
                            valueRange = 0.0f..3.0f,
                            colors = SliderDefaults.colors(
                                thumbColor = Color(0xFF00E5FF),
                                activeTrackColor = Color(0xFFBC00DD),
                                inactiveTrackColor = Color(0xFF321A4F)
                            )
                        )
                    }
                    Spacer(modifier = Modifier.width(8.dp))
                    Icon(
                        imageVector = Icons.Rounded.VolumeUp,
                        contentDescription = "Volume icon",
                        tint = Color(0xFF00E5FF),
                        modifier = Modifier.size(20.dp)
                    )
                }

                Spacer(modifier = Modifier.height(8.dp))

                // Acoustic Echo Cancellation status badge
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "Hardware Echo Canceler (AEC):",
                        color = Color.Gray,
                        fontSize = 11.sp
                    )

                    val aecText = if (isMicActive) {
                        if (isAecEnabled) "ACTIVE (VOICE_COMM)" else "NOT SUPPORTED"
                    } else {
                        "READY"
                    }
                    val aecColor = if (isMicActive) {
                        if (isAecEnabled) Color(0xFF00E5FF) else Color(0xFFFFA726)
                    } else {
                        Color.Gray
                    }

                    Text(
                        text = aecText,
                        color = aecColor,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }
    }
}

@Composable
fun YouTubeHelperCard(
    onSearchQuery: (String) -> Unit,
    onToggleWebView: () -> Unit,
    isWebViewVisible: Boolean
) {
    var searchInput by remember { mutableStateOf("") }
    val presets = listOf(
        "Bohemian Rhapsody", "I Will Survive", "Hotel California", "Don't Stop Believin'", "My Way", "Perfect"
    )

    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = Color(0xFF160A24)),
        border = BorderStroke(1.dp, Color(0xFF00E5FF).copy(alpha = 0.3f))
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(20.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "YOUTUBE BACKING TRACKS",
                    color = Color.White,
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 2.sp
                )

                Button(
                    onClick = onToggleWebView,
                    colors = ButtonDefaults.buttonColors(
                        containerColor = if (isWebViewVisible) Color(0x3300E5FF) else Color(0xFF00E5FF)
                    ),
                    contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp),
                    modifier = Modifier.height(32.dp)
                ) {
                    Text(
                        text = if (isWebViewVisible) "HIDE PLAYER" else "SHOW PLAYER",
                        color = if (isWebViewVisible) Color(0xFF00E5FF) else Color.Black,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            // Search text field
            OutlinedTextField(
                value = searchInput,
                onValueChange = { searchInput = it },
                placeholder = { Text("Search YouTube Karaoke...", color = Color.Gray) },
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("youtube_search_input"),
                trailingIcon = {
                    IconButton(
                        onClick = {
                            if (searchInput.isNotBlank()) {
                                onSearchQuery(searchInput)
                            }
                        }
                    ) {
                        Icon(
                            imageVector = Icons.Rounded.Search,
                            contentDescription = "Search button",
                            tint = Color(0xFF00E5FF)
                        )
                    }
                },
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = Color(0xFF00E5FF),
                    unfocusedBorderColor = Color(0xFF2E1A47),
                    focusedContainerColor = Color(0xFF0B0014),
                    unfocusedContainerColor = Color(0xFF0B0014),
                    focusedTextColor = Color.White,
                    unfocusedTextColor = Color.White
                ),
                shape = RoundedCornerShape(12.dp),
                singleLine = true
            )

            Spacer(modifier = Modifier.height(14.dp))

            Text(
                text = "Popular Karaoke Presets:",
                color = Color.Gray,
                fontSize = 12.sp,
                fontWeight = FontWeight.Medium
            )

            Spacer(modifier = Modifier.height(8.dp))

            // Chips/Presets horizontal scroll row
            LazyRow(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                items(presets) { track ->
                    AssistChip(
                        onClick = {
                            searchInput = track
                            onSearchQuery(track)
                        },
                        label = { Text(track, color = Color.White, fontSize = 11.sp) },
                        colors = AssistChipDefaults.assistChipColors(
                            containerColor = Color(0xFF231336)
                        ),
                        border = BorderStroke(
                            width = 1.dp,
                            color = Color(0xFFBC00DD).copy(alpha = 0.3f)
                        ),
                        shape = RoundedCornerShape(8.dp)
                    )
                }
            }
        }
    }
}

@Composable
fun AudioVisualizer(amplitude: Float, modifier: Modifier = Modifier) {
    Row(
        modifier = modifier,
        horizontalArrangement = Arrangement.spacedBy(4.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        val barsCount = 18
        for (i in 0 until barsCount) {
            // Generate some responsive but beautifully balanced scale factors for each bar
            val factor = when {
                i == 0 || i == 17 -> 0.2f
                i == 1 || i == 16 -> 0.4f
                i == 2 || i == 15 -> 0.6f
                i == 3 || i == 14 -> 0.8f
                i % 3 == 0 -> 1.0f
                i % 3 == 1 -> 0.7f
                else -> 0.5f
            }
            // Add a very small baseline so the bars never disappear completely
            val heightScale = (amplitude * factor).coerceIn(0.08f, 1.0f)
            Box(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxHeight(heightScale)
                    .background(
                        brush = Brush.verticalGradient(
                            colors = listOf(
                                Color(0xFF00E5FF), // Cyber Cyan
                                Color(0xFFBC00DD)  // Cyber Magenta
                            )
                        ),
                        shape = RoundedCornerShape(3.dp)
                    )
            )
        }
    }
}

// Utility function to scan output devices for headphones
fun checkHeadphones(context: Context): Boolean {
    val audioManager = context.getSystemService(Context.AUDIO_SERVICE) as AudioManager
    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
        val devices = audioManager.getDevices(AudioManager.GET_DEVICES_OUTPUTS)
        for (device in devices) {
            if (device.type == AudioDeviceInfo.TYPE_WIRED_HEADSET ||
                device.type == AudioDeviceInfo.TYPE_WIRED_HEADPHONES ||
                device.type == AudioDeviceInfo.TYPE_BLUETOOTH_A2DP ||
                device.type == AudioDeviceInfo.TYPE_BLUETOOTH_SCO
            ) {
                return true
            }
        }
        return false
    } else {
        @Suppress("DEPRECATION")
        return audioManager.isWiredHeadsetOn
    }
}
