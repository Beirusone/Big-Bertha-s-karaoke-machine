package com.example.services

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioManager
import android.media.AudioRecord
import android.media.AudioTrack
import android.media.MediaRecorder
import android.media.audiofx.AcousticEchoCanceler
import android.os.Build
import android.os.IBinder
import android.util.Log
import androidx.core.app.NotificationCompat
import com.example.MainActivity
import com.example.R
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow

class KaraokeService : Service() {

    companion object {
        private const val TAG = "KaraokeService"
        private const val NOTIFICATION_ID = 1001
        private const val CHANNEL_ID = "karaoke_mic_channel"

        private val _isMicActive = MutableStateFlow(false)
        val isMicActive = _isMicActive.asStateFlow()

        private val _micVolume = MutableStateFlow(1.0f)
        val micVolume = _micVolume.asStateFlow()

        private val _amplitude = MutableStateFlow(0f)
        val amplitude = _amplitude.asStateFlow()

        private val _isAecEnabled = MutableStateFlow(false)
        val isAecEnabled = _isAecEnabled.asStateFlow()

        fun setMicVolume(volume: Float) {
            _micVolume.value = volume.coerceIn(0f, 3f) // allow boosting up to 3x
        }

        fun startService(context: Context) {
            val intent = Intent(context, KaraokeService::class.java)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                context.startForegroundService(intent)
            } else {
                context.startService(intent)
            }
        }

        fun stopService(context: Context) {
            val intent = Intent(context, KaraokeService::class.java)
            context.stopService(intent)
        }
    }

    private var audioRecord: AudioRecord? = null
    private var audioTrack: AudioTrack? = null
    private var echoCanceler: AcousticEchoCanceler? = null
    private var loopbackThread: Thread? = null
    private var isRunning = false

    override fun onCreate() {
        super.onCreate()
        createNotificationChannel()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val notification = buildNotification()
        startForeground(NOTIFICATION_ID, notification)

        if (!isRunning) {
            startAudioLoopback()
        }

        return START_STICKY
    }

    override fun onBind(intent: Intent?): IBinder? = null

    private fun startAudioLoopback() {
        isRunning = true
        _isMicActive.value = true

        loopbackThread = Thread {
            val sampleRate = 44100
            val audioFormat = AudioFormat.ENCODING_PCM_16BIT

            // Find valid buffer size
            val minRecordBufSize = AudioRecord.getMinBufferSize(
                sampleRate,
                AudioFormat.CHANNEL_IN_MONO,
                audioFormat
            )

            val bufferSize = if (minRecordBufSize != AudioRecord.ERROR && minRecordBufSize != AudioRecord.ERROR_BAD_VALUE) {
                (minRecordBufSize * 2).coerceAtLeast(4096)
            } else {
                8192
            }

            try {
                // Initialize AudioRecord with VOICE_COMMUNICATION for echo cancellation
                audioRecord = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                    val attributionContext = createAttributionContext("microphone")
                    AudioRecord.Builder()
                        .setContext(attributionContext)
                        .setAudioSource(MediaRecorder.AudioSource.VOICE_COMMUNICATION)
                        .setAudioFormat(
                            AudioFormat.Builder()
                                .setEncoding(audioFormat)
                                .setSampleRate(sampleRate)
                                .setChannelMask(AudioFormat.CHANNEL_IN_MONO)
                                .build()
                        )
                        .setBufferSizeInBytes(bufferSize)
                        .build()
                } else {
                    AudioRecord(
                        MediaRecorder.AudioSource.VOICE_COMMUNICATION,
                        sampleRate,
                        AudioFormat.CHANNEL_IN_MONO,
                        audioFormat,
                        bufferSize
                    )
                }

                if (audioRecord?.state != AudioRecord.STATE_INITIALIZED) {
                    Log.e(TAG, "Failed to initialize AudioRecord")
                    stopSelf()
                    return@Thread
                }

                // Check and enable hardware Acoustic Echo Canceler (AEC)
                if (AcousticEchoCanceler.isAvailable()) {
                    try {
                        echoCanceler = AcousticEchoCanceler.create(audioRecord!!.audioSessionId).apply {
                            enabled = true
                        }
                        _isAecEnabled.value = echoCanceler?.enabled == true
                        Log.d(TAG, "Hardware echo canceler enabled: ${echoCanceler?.enabled}")
                    } catch (e: Exception) {
                        Log.e(TAG, "Error enabling hardware Acoustic Echo Canceler", e)
                        _isAecEnabled.value = false
                    }
                } else {
                    Log.d(TAG, "Hardware Acoustic Echo Canceler is not supported on this device")
                    _isAecEnabled.value = false
                }

                // Initialize AudioTrack for real-time playout on music stream
                val minTrackBufSize = AudioTrack.getMinBufferSize(
                    sampleRate,
                    AudioFormat.CHANNEL_OUT_MONO,
                    audioFormat
                )

                audioTrack = AudioTrack.Builder()
                    .setAudioAttributes(
                        AudioAttributes.Builder()
                            .setUsage(AudioAttributes.USAGE_MEDIA)
                            .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                            .build()
                    )
                    .setAudioFormat(
                        AudioFormat.Builder()
                            .setEncoding(audioFormat)
                            .setSampleRate(sampleRate)
                            .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
                            .build()
                    )
                    .setBufferSizeInBytes(minTrackBufSize.coerceAtLeast(bufferSize))
                    .setTransferMode(AudioTrack.MODE_STREAM)
                    .build()

                if (audioTrack?.state != AudioTrack.STATE_INITIALIZED) {
                    Log.e(TAG, "Failed to initialize AudioTrack")
                    stopSelf()
                    return@Thread
                }

                // Start recording and playout
                audioRecord!!.startRecording()
                audioTrack!!.play()

                val buffer = ShortArray(bufferSize / 2)
                Log.d(TAG, "Mic loopback loop started successfully.")

                while (isRunning) {
                    val readBytes = audioRecord!!.read(buffer, 0, buffer.size)
                    if (readBytes > 0) {
                        // Calculate real-time amplitude/RMS for UI visualizer pulses
                        var sum = 0.0
                        for (i in 0 until readBytes) {
                            val sample = buffer[i].toDouble()
                            sum += sample * sample
                        }
                        val rms = Math.sqrt(sum / readBytes).toFloat()
                        // Normalize and amplify for nice UI feedback
                        val normalized = (rms / 32768f) * 8f
                        _amplitude.value = normalized.coerceIn(0f, 1f)

                        // Apply volume scaling/boosting
                        val vol = _micVolume.value
                        if (vol != 1.0f) {
                            for (i in 0 until readBytes) {
                                val scaled = (buffer[i] * vol).toInt()
                                buffer[i] = scaled.coerceIn(Short.MIN_VALUE.toInt(), Short.MAX_VALUE.toInt()).toShort()
                            }
                        }

                        audioTrack!!.write(buffer, 0, readBytes)
                    } else if (readBytes < 0) {
                        Log.e(TAG, "AudioRecord read error: $readBytes")
                        break
                    }
                }
            } catch (e: SecurityException) {
                Log.e(TAG, "Permission denied for recording audio", e)
            } catch (e: Exception) {
                Log.e(TAG, "Exception in loopback thread", e)
            } finally {
                cleanUpAudio()
            }
        }

        loopbackThread?.start()
    }

    private fun cleanUpAudio() {
        try {
            audioRecord?.let {
                if (it.recordingState == AudioRecord.RECORDSTATE_RECORDING) {
                    it.stop()
                }
                it.release()
            }
        } catch (e: Exception) {
            Log.e(TAG, "Error cleaning up AudioRecord", e)
        }
        audioRecord = null

        try {
            audioTrack?.let {
                if (it.playState == AudioTrack.PLAYSTATE_PLAYING) {
                    it.stop()
                }
                it.release()
            }
        } catch (e: Exception) {
            Log.e(TAG, "Error cleaning up AudioTrack", e)
        }
        audioTrack = null

        try {
            echoCanceler?.let {
                it.enabled = false
                it.release()
            }
        } catch (e: Exception) {
            Log.e(TAG, "Error cleaning up echoCanceler", e)
        }
        echoCanceler = null

        _isMicActive.value = false
        _amplitude.value = 0f
        _isAecEnabled.value = false
    }

    override fun onDestroy() {
        isRunning = false
        _isMicActive.value = false
        _amplitude.value = 0f
        _isAecEnabled.value = false
        loopbackThread?.interrupt()
        cleanUpAudio()
        super.onDestroy()
    }

    private fun buildNotification(): Notification {
        val stopIntent = Intent(this, KaraokeService::class.java).apply {
            action = "STOP_MIC_ACTION"
        }
        // In the next step we will handle the Stop action in onStartCommand if needed.
        // Or simple click pending intent.
        val mainIntent = Intent(this, MainActivity::class.java)
        val mainPendingIntent = PendingIntent.getActivity(
            this,
            0,
            mainIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("Karaoke Mic Active")
            .setContentText("Microphone monitoring is active in the background.")
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setContentIntent(mainPendingIntent)
            .setOngoing(true)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .setCategory(NotificationCompat.CATEGORY_SERVICE)
            .build()
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val name = "Karaoke Microphone Monitor"
            val descriptionText = "Persistent notification indicating the microphone monitoring service is running in the background."
            val importance = NotificationManager.IMPORTANCE_LOW
            val channel = NotificationChannel(CHANNEL_ID, name, importance).apply {
                description = descriptionText
            }
            val notificationManager: NotificationManager =
                getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            notificationManager.createNotificationChannel(channel)
        }
    }
}
